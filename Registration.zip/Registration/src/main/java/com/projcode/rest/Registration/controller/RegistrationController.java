package com.projcode.rest.Registration.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import com.projcode.rest.Registration.entity.Registration;

import java.util.List;
import java.util.Map;

@RestController
public class RegistrationController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping("/api/registration")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Registration registration) {
        try {
            String sql = "INSERT INTO REGISTRATION (firstname, lastname, dob, salary, gender, isEligible, username, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            jdbcTemplate.update(sql,
                    registration.getFirstname(),
                    registration.getLastname(),
                    registration.getDob(),
                    registration.getSalary(),
                    registration.getGender(),
                    registration.isEligible(),
                    registration.getUsername(),
                    registration.getDepartment());

            return ResponseEntity.ok(Map.of("success", true, "message", "Registration successful"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("success", false, "message", "Registration failed: " + e.getMessage()));
        }
    }
    

    @GetMapping("/api/registrations")
    public ResponseEntity<List<Registration>> getAllRegistrations() {
        try {
            String sql = "SELECT * FROM REGISTRATION";
            List<Registration> registrations = jdbcTemplate.query(sql, (rs, rowNum) ->
                    new Registration(
                            rs.getInt("id"),
                            rs.getString("firstname"),
                            rs.getString("lastname"),
                            rs.getString("dob"),
                            rs.getDouble("salary"),
                            rs.getString("gender"),
                            rs.getBoolean("isEligible"),
                            rs.getString("username"),
                            rs.getString("department")
                    )
            );
            return ResponseEntity.ok(registrations);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}