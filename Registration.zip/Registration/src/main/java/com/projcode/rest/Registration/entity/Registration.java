package com.projcode.rest.Registration.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Registration {

	     @Id
	     @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private int id;
	     @Column
	    private String firstname; 
	     @Column
	    private String lastname; 
	     @Column
	    private String dob;
	     @Column
	    private double salary;
	     @Column
	    private String gender;
	     @Column
	    private boolean isEligible; 
	     @Column
	    private String username;   
	     @Column
	    private String department;

	   
	    public Registration() {}

	    public Registration(int id, String firstname, String lastname, String dob, double salary, String gender, boolean is_eligible, String user_name, String department) {
	        this.id = id;
	        this.firstname = firstname;
	        this.lastname = lastname;
	        this.dob = dob;
	        this.salary = salary;
	        this.gender = gender;
	        this.isEligible = is_eligible;
	        this.username = user_name;
	        this.department = department;
	    }

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public String getDob() {
			return dob;
		}

		public void setDob(String dob) {
			this.dob = dob;
		}

		public double getSalary() {
			return salary;
		}

		public void setSalary(double salary) {
			this.salary = salary;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public boolean isEligible() {
			return isEligible;
		}

		public void setEligible(boolean isEligible) {
			this.isEligible = isEligible;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		

		
	
	
    
}
