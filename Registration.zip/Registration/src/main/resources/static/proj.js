const form = document.getElementById('registrationForm');
const firstName = document.getElementById('firstName');
const lastName = document.getElementById('lastName');
const dob = document.getElementById('dob');
const salary = document.getElementById('salary');
const gender = document.getElementById('gender');
const isEligible = document.getElementById('isEligible');
const userName = document.getElementById('userName');
const department = document.getElementById('department');
const resetButton = document.getElementById('resetButton');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    // Validation
    let isValid = true;
    let errorMessage = "";

    // Required fields check
    if (!firstName.value || !lastName.value || !dob.value || !userName.value || !department.value) {
        isValid = false;
        errorMessage += "Please fill in all required fields.\n";
    }

    // Alphabetic validation for first and last name
    if (!/^[A-Za-z]+$/.test(firstName.value) || !/^[A-Za-z]+$/.test(lastName.value)) {
        isValid = false;
        errorMessage += "First and last names must contain only alphabetic characters.\n";
    }

    // Date validation (dd-MM-yyyy)
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dob.value)) { // Assuming date is in yyyy-MM-dd format from input type="date"
        isValid = false;
        errorMessage += "Please enter a valid date.\n";
    }

    // Salary validation (double number)
    if (salary.value && isNaN(parseFloat(salary.value))) {
        isValid = false;
        errorMessage += "Salary must be a valid number.\n";
    }

    // Username validation
    if (!/^(?=.*[A-Z])(?=.*[0-9])(?=.*[_.\-])[A-Za-z0-9_.\-]{6,8}$/.test(userName.value)) {
        isValid = false;
        errorMessage += "Username must be 6-8 characters, contain at least 1 capital letter, 1 number, and 1 special character (_.-).\n";
    }

    if (!isValid) {
        alert(errorMessage);
        return;
    }

    // Prepare data for submission
    const formData = {
        firstName: firstName.value,
        lastName: lastName.value,
        dob: dob.value,
        salary: salary.value ? parseFloat(salary.value) : null,
        gender: gender.value,
        isEligible: isEligible.checked,
        userName: userName.value,
        department: department.value
    };

    // Send POST request
    axios.post('/api/registration', formData)
        .then(function(response) {
            alert('Registration successful!');
            form.reset();
        })
        .catch(function(error) {
            alert('Registration failed: ' + error.message);
        });
});

resetButton.addEventListener('click', function(event) {
    form.reset();
});